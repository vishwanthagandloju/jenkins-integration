package com.aspectsecurity.contrast.contrastjenkins;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class App {

    public String name;
    public String title;
}
