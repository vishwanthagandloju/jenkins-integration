INSERT INTO PUBLIC.PROVIDERS (id, first_name, last_name, phone, street_address, city, state, zip_code, specialty, public_listing, suspended, taking_new_patients)
VALUES
	(1,'Stephen','Milner','410-333-3333','101 Main St','Baltimore','MD','21230','Internal Medicine',TRUE,FALSE,FALSE),
	(2,'Jane','Owens','410-333-3333','102 Main St','Baltimore','MD','21230','General Practice',TRUE,FALSE,TRUE),
	(3,'Alfred','Newman','410-333-3333','103 Main St','Baltimore','MD','21230','Ear, Nose, and Throat',FALSE,TRUE,FALSE);