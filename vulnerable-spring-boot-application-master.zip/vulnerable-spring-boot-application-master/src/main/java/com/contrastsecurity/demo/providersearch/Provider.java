package com.contrastsecurity.demo.providersearch;

public class Provider {

}
