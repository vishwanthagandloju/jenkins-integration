package com.contrastsecurity.demo.providersearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProviderSearchApplication.class, args);
	}
}
