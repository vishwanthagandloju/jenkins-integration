package com.contrastsecurity.demo.providersearch;

public class SearchForm {
    String zipCode;

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}
